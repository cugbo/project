from django.apps import AppConfig


class MadusonovidiusscrumyConfig(AppConfig):
    name = 'madusonovidiusscrumy'
